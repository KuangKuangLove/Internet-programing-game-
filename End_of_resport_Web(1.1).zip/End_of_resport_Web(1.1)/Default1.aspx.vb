﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim sql_cn As String = "Data Source=(LocalDB)\MSSQLLocalDB;" &
            "AttachDbFilename=" &
               Server.MapPath("App_Data\Data.mdf") &
            ";Integrated Security=True"
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        Image1.ImageUrl = "123.jpg"
        'Dim sqlrow As DataRow
        'For Each sqlrow In ds.Tables("ac_paw_data").Rows
        '    Label1.Text &= sqlrow("Name") & "-"
        'Next
        'sc.Close()



    End Sub
    Sub show_data()
        Dim sql_cn As String = "Data Source=(LocalDB)\MSSQLLocalDB;" &
            "AttachDbFilename=" &
               Server.MapPath("App_Data\Data.mdf") &
            ";Integrated Security=True"
        Dim sc As SqlConnection = New SqlConnection()
        sc.ConnectionString = sql_cn
        sc.Open()
        Dim cmd As SqlDataAdapter = New SqlDataAdapter("SELECT * FROM ac_paw_data", sc)
        Dim ds As DataSet = New DataSet()
        cmd.Fill(ds, "ac_paw_data")
        'GridView1.DataSource = ds.Tables("ac_paw_data")
        sc.Close()


    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim sc As SqlConnection = New SqlConnection()
        sc.ConnectionString = sql_cn
        sc.Open()
        Dim cmd As SqlCommand = New SqlCommand("GetData", sc)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add(New SqlParameter("@name", SqlDbType.NVarChar))
        cmd.Parameters.Add(New SqlParameter("@password", SqlDbType.NVarChar))
        cmd.Parameters("@name").Value = TextBox1.Text
        cmd.Parameters("@password").Value = TextBox2.Text
        Dim dr As SqlDataReader = cmd.ExecuteReader()
        If dr.Read() Then
            Label1.Text = "登入成功"
            Session("name") = TextBox1.Text
            Response.Redirect("Menu.aspx")
        Else
            Label1.Text = "登入失敗"
        End If
        sc.Close()
    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click


        Dim sc As SqlConnection = New SqlConnection()
            sc.ConnectionString = sql_cn
            sc.Open()
        Dim sql_str As String = "INSERT INTO ac_paw_data(Name,Password) VALUES (@name,@password)"
        Dim cmd As SqlCommand = New SqlCommand(sql_str, sc)

            'cmd.Parameters.Add(New SqlParameter("@id", SqlDbType.Int))
            cmd.Parameters.Add(New SqlParameter("@name", SqlDbType.NVarChar))
            cmd.Parameters.Add(New SqlParameter("@password", SqlDbType.NVarChar))
            cmd.Parameters("@name").Value = TextBox1.Text
            cmd.Parameters("@password").Value = TextBox2.Text
        cmd.ExecuteNonQuery()
        MsgBox("註冊成功", 64, "Message")





    End Sub
End Class
