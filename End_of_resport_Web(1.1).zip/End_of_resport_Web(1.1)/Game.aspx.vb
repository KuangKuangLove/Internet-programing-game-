﻿
Imports System.Data
Imports System.Data.SqlClient
Partial Class Game
    Inherits System.Web.UI.Page


    'Dim a As Integer = 0
    'Dim b As Integer = 100
    'Dim r As Integer
    Dim Score As Integer
    Dim a As Integer
    Dim b As Integer
    Dim r As Integer
    Dim sql_cn As String = "Data Source=(LocalDB)\MSSQLLocalDB;" &
            "AttachDbFilename=" &
               Server.MapPath("App_Data\Data.mdf") &
            ";Integrated Security=True"
    Dim name As String
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        Image1.ImageUrl = "123.jpg"
        a = 0
        b = 100
        Score = 100
        If Page.IsPostBack Then
            a = CInt(Label1.Text)
            b = CInt(Label2.Text)
            Score = CInt(Label4.Text)
        End If
        r = Session("r")
        Label1.Text = a
        Label2.Text = b
        Label4.Text = Score
        Button2.Visible = False
        Button3.Visible = False


    End Sub


    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click



        name = Session("name")
        If CInt(TextBox1.Text) < r Then
            a = CInt(TextBox1.Text)
            Label1.Text = a
            Score = Score - 10
            Label4.Text = Score
            RangeValidator1.MinimumValue = CInt(TextBox1.Text)
        End If

        If CInt(TextBox1.Text) > r Then
            b = CInt(TextBox1.Text)
            Label2.Text = b
            Score = Score - 10
            Label4.Text = Score
            RangeValidator1.MaximumValue = CInt(TextBox1.Text)
        End If

        If CInt(TextBox1.Text) = r Then
            Label3.Text = "恭喜，猜中了!!!"
            Button1.Enabled = False
            Label4.Text = Score
            Label6.Text = "總得分"
             Dim ck As Boolean = False
            Dim sc As SqlConnection = New SqlConnection()
            sc.ConnectionString = sql_cn
            sc.Open()
            Dim cmd1 As SqlCommand = New SqlCommand("SELECT [Score] FROM ac_paw_data WHERE Name=@name", sc)
            cmd1.Parameters.Add(New SqlParameter("@name", SqlDbType.NVarChar))
            cmd1.Parameters("@name").Value = name
            Dim dr As SqlDataReader = cmd1.ExecuteReader()
            If dr.Read() Then

                If dr("Score").ToString() = "" Then
                    sc.Close()
                    sc.Open()
                    Dim cmd As SqlCommand = New SqlCommand("Update", sc)
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.Add(New SqlParameter("@name", SqlDbType.NVarChar))
                    cmd.Parameters.Add(New SqlParameter("@score", SqlDbType.NVarChar))
                    cmd.Parameters("@name").Value = name
                    cmd.Parameters("@score").Value = Score
                    cmd.ExecuteNonQuery()
                    ck = True
                ElseIf ck = False Then
                    If CInt(dr("Score")) < Score Then
                        sc.Close()
                        sc.Open()
                        Dim cmd As SqlCommand = New SqlCommand("Update", sc)
                        cmd.CommandType = CommandType.StoredProcedure
                        cmd.Parameters.Add(New SqlParameter("@name", SqlDbType.NVarChar))
                        cmd.Parameters.Add(New SqlParameter("@score", SqlDbType.NVarChar))
                        cmd.Parameters("@name").Value = name
                        cmd.Parameters("@score").Value = Score
                        cmd.ExecuteNonQuery()
                    End If
                End If
                End If
            Button2.Visible = True
            Button3.Visible = True
            sc.Close()
        End If


    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Response.Redirect("Menu.aspx")
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Response.Redirect("Rank.aspx")
    End Sub
End Class
