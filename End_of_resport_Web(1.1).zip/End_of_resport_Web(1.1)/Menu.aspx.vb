﻿
Partial Class Menu
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        Label1.Visible = False
        Image1.ImageUrl = "123.jpg"
        Label2.Text = Session("Name")

    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        Label1.Text = "遊戲規則 : 電腦將隨機從1~100選一個數字，而玩家必須從1到100中猜出這一個數字，第一次猜中即可拿100分，第二次90分...(以此類推)"
        Label1.Visible = True

    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        'Randomize()
        Dim name As String
        name = Session("name")
        Dim r As Integer = Int(Rnd() * 99) + 1
        Dim Score = 10
        Session("r") = r
        Session("Score") = Score
        Session("name") = name
        Response.Redirect("Game.aspx")

    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Response.Redirect("Rank.aspx")

    End Sub
End Class
